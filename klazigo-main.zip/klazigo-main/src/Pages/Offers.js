import React from "react";

const Offers = () => {
	return <div>This is Offers Page</div>;
};

export default Offers;
