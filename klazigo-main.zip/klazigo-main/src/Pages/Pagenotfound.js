import React from "react";

function Pagenotfound() {
	return <h2>Page Not Found</h2>;
}

export default Pagenotfound;
