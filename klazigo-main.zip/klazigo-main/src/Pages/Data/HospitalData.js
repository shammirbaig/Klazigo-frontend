const HospitalData = [
	{ id: 1, hospitalName: "Yashoda Hospital", distance: 5, fee: 150, stars: 4 },
	{ id: 2, hospitalName: "Yashoda Hospital", distance: 4, fee: 150, stars: 3 },
	{ id: 3, hospitalName: "Yashoda Hospital", distance: 4, fee: 150, stars: 3 },
	{ id: 4, hospitalName: "Yashoda Hospital", distance: 1, fee: 150, stars: 3 },
	{ id: 5, hospitalName: "Yashoda Hospital", distance: 1, fee: 150, stars: 1 },
	{ id: 6, hospitalName: "Yashoda Hospital", distance: 3, fee: 150, stars: 2 },
	{ id: 7, hospitalName: "Yashoda Hospital", distance: 2, fee: 150, stars: 2 },
	{ id: 8, hospitalName: "Yashoda Hospital", distance: 3, fee: 150, stars: 4 },
	{ id: 9, hospitalName: "Yashoda Hospital", distance: 3, fee: 150, stars: 2 },
	{ id: 10, hospitalName: "Yashoda Hospital", distance: 2.2, fee: 150, stars: 3 },
	{ id: 11, hospitalName: "Yashoda Hospital", distance: 3.5, fee: 150, stars: 1 },
	{ id: 12, hospitalName: "Yashoda Hospital", distance: 1.45, fee: 150, stars: 1 },
];

export default HospitalData;
