/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		id: 1,
		name: "Accu-chek Active Blood Glucometer Kit( Box of 10 strips Free)",
		sellingPrice: 1279,
		costPrice: 1500,
		packetInfo: "Packet of 1 Kit",
		count: 1,
	},
	{
		id: 2,
		name: "Limcee Chewable Tablet Orange",
		sellingPrice: 129,
		costPrice: 150,
		packetInfo: "Strip of 15 chewable tablets \nMinumum order quantity:3",
		count: 1,
	},
	{
		id: 3,
		name: "Accu-chek Active Blood Glucometer Kit( Box of 10 strips Free)",
		sellingPrice: 1279,
		costPrice: 1500,
		packetInfo: "Packet of 1 Kit",
		count: 1,
	},
];
