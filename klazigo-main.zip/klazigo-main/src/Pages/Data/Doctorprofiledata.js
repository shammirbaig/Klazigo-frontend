/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		id: 800,
		name: "Dr.Sultana Begum",
		redirect: true,
		pageLink: "/DrSultanaBegum",
		qualification: "MBBS",
		experience: "12 yrs",
		AvailableToday: true,
		experienceInfo: "General physician,24 years of experience Apollo hospitals",
		image: require("../../Images/doctorProfileImg.png"),
	},
];
