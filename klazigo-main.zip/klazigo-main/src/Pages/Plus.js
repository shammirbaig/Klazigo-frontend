import React from "react";

const Plus = () => {
	return <div>This is Plus Page</div>;
};

export default Plus;
