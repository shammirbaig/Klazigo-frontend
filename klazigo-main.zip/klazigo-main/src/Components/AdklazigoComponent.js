import React from "react";

const Adklazigocomponent = () => {
	return (
		<>
			<section className="ad">
				<div className="container">
					<span className="container__content">Advertisement/Klazigo Banner</span>
				</div>
			</section>
		</>
	);
};

export default Adklazigocomponent;
