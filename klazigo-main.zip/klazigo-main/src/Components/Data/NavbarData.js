/* eslint-disable import/no-anonymous-default-export */
export default ["Doctors", "Medicine", "Plus", "Offers"];
