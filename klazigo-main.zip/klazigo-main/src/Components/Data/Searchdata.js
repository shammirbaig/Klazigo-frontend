/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		location: "New Delhi",
		name: "Government Hospital, New Delhi",
	},
	{
		location: "Chirala",
		name: "Anusha Hospital, Chirala",
	},
	{
		location: "Tirupati",
		name: "Aims Hospital,Tirupati",
	},
	{
		location: "Chennai",
		name: "Amma Hospital, Chennai",
	},
	{
		location: "Ongole",
		name: "Superspeciality Hospita, Ongole",
	},
	{
		location: "Bangalore",
		name: "Apolo Hospital, Bangalore",
	},
];
