/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		type: "For Patients",
		links: {
			hospitals: "Search for Hospitals",
			clinics: "Search for Clinics",
			doctors: "Search for Doctors",
			articles: "Health Articles",
			app: "Health App",
		},
	},
	{
		type: "For Doctors",
		links: {
			hospitals: "Search for Hospitals",
			clinics: "Search for Clinics",
			doctors: "Search for Doctors",
			articles: "Health Articles",
			app: "Health App",
		},
	},
	{
		type: "For Hospitals",
		links: {
			hospitals: "Search for Hospitals",
			clinics: "Search for Clinics",
			doctors: "Search for Doctors",
			articles: "Health Articles",
			app: "Health App",
		},
	},
	{
		type: "For Medical Stores",
		links: {
			hospitals: "Search for Hospitals",
			clinics: "Search for Clinics",
			doctors: "Search for Doctors",
			articles: "Health Articles",
			app: "Health App",
		},
	},
	{
		type: "More",
		links: {
			hospitals: "Search for Hospitals",
			clinics: "Search for Clinics",
			doctors: "Search for Doctors",
			articles: "Health Articles",
			app: "Health App",
		},
	},
];
