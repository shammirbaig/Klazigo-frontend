/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		info: "Winter-Care",
		image: require("../../Images/medicine-winter-care.png"),
	},
	{
		info: "Skin Care",
		image: require("../../Images/medicine-winter-care.png"),
	},
	{
		info: "Diabetes",
		image: require("../../Images/medicine-winter-care.png"),
	},
	{
		info: "Ayurveda",
		image: require("../../Images/medicine-winter-care.png"),
	},
	{
		info: "Vitamins and \n Supplements",
		image: require("../../Images/medicine-winter-care.png"),
	},
	{
		info: "Health care devices",
		image: require("../../Images/medicine-winter-care.png"),
	},
];
