/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		id: 1,
		image: require(""),
		info: "Hospitals",
	},
	{
		id: 1,
		image: require(""),
		info: "Doctors",
	},
	{
		id: 1,
		image: require(""),
		info: "Medicine",
	},
	{
		id: 1,
		image: require(""),
		info: "Plus",
	},
];
