/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		image: require("../../Images/Mask group.jpg"),
		info: "General Physician",
	},
	{
		image: require("../../Images/Ellipse 8.jpg"),
		info: "Dermatology",
	},
	{
		image: require("../../Images/Mask group-1.jpg"),
		info: "Cardiology",
	},
	{
		image: require("../../Images/Mask group-2.jpg"),
		info: "Gyanaecology",
	},
	{
		image: require("../../Images/Mask group-3.jpg"),
		info: "Urology",
	},
	{
		image: require("../../Images/Mask group-4.jpg"),
		info: "Neurology",
	},
];
