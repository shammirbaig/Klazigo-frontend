/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		info: "Multi-speciality",
		image: require("../../Images/hospitalsimg.png"),
	},
	{
		info: "Eye Hospitals \n Clinics",
		image: require("../../Images/hospitalsimg.png"),
	},
	{
		info: "Ears Nose and \n Tongue",
		image: require("../../Images/hospitalsimg.png"),
	},
	{
		info: "Dental",
		image: require("../../Images/hospitalsimg.png"),
	},
	{
		info: "Test center",
		image: require("../../Images/hospitalsimg.png"),
	},
	{
		info: "Checkup \n @Home",
		image: require("../../Images/hospitalsimg.png"),
	},
];
