/* eslint-disable import/no-anonymous-default-export */
export default [
	{
		image: require("../../Images/Healtharticle.jpg"),
		info: "'Skinfluencers' Promote Risky Beauty Hacks on TikTok",
	},
];
